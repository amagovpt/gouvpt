.. _example_index:

Quick pysaml2 example
=====================

:Release: |version|
:Date: |today|

In order to confirm that pysaml2 has been installed correctly and are ready to use you could run this basic example

Contents:

.. toctree::
   :maxdepth: 1

   sp
   idp
   
