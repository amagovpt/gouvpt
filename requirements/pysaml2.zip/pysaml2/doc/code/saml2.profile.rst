profile Package
===============

:mod:`profile` Package
----------------------

.. automodule:: saml2.profile
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`ecp` Module
-----------------

.. automodule:: saml2.profile.ecp
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`paos` Module
------------------

.. automodule:: saml2.profile.paos
    :members:
    :undoc-members:
    :show-inheritance:

