entity_category Package
=======================

:mod:`entity_category` Package
------------------------------

.. automodule:: saml2.entity_category
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`at_egov_pvp2` Module
--------------------------

.. automodule:: saml2.entity_category.at_egov_pvp2
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`edugain` Module
---------------------

.. automodule:: saml2.entity_category.edugain
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`incommon` Module
----------------------

.. automodule:: saml2.entity_category.incommon
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`refeds` Module
--------------------

.. automodule:: saml2.entity_category.refeds
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`swamid` Module
--------------------

.. automodule:: saml2.entity_category.swamid
    :members:
    :undoc-members:
    :show-inheritance:

