plugins Package
===============

:mod:`plugins` Package
----------------------

.. automodule:: s2repoze.plugins
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`challenge_decider` Module
-------------------------------

.. automodule:: s2repoze.plugins.challenge_decider
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`entitlement` Module
-------------------------

.. automodule:: s2repoze.plugins.entitlement
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`formswithhidden` Module
-----------------------------

.. automodule:: s2repoze.plugins.formswithhidden
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`ini` Module
-----------------

.. automodule:: s2repoze.plugins.ini
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`sp` Module
----------------

.. automodule:: s2repoze.plugins.sp
    :members:
    :undoc-members:
    :show-inheritance:

