userinfo Package
================

:mod:`userinfo` Package
-----------------------

.. automodule:: saml2.userinfo
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`ldapinfo` Module
----------------------

.. automodule:: saml2.userinfo.ldapinfo
    :members:
    :undoc-members:
    :show-inheritance:

