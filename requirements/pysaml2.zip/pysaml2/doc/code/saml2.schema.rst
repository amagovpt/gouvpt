schema Package
==============

:mod:`schema` Package
---------------------

.. automodule:: saml2.schema
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`soap` Module
------------------

.. automodule:: saml2.schema.soap
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`soapenv` Module
---------------------

.. automodule:: saml2.schema.soapenv
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`wsdl` Module
------------------

.. automodule:: saml2.schema.wsdl
    :members:
    :undoc-members:
    :show-inheritance:

