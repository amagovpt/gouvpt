extension Package
=================

:mod:`extension` Package
------------------------

.. automodule:: saml2.extension
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`algsupport` Module
------------------------

.. automodule:: saml2.extension.algsupport
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dri` Module
-----------------

.. automodule:: saml2.extension.dri
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`idpdisc` Module
---------------------

.. automodule:: saml2.extension.idpdisc
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mdattr` Module
--------------------

.. automodule:: saml2.extension.mdattr
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mdrpi` Module
-------------------

.. automodule:: saml2.extension.mdrpi
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mdui` Module
------------------

.. automodule:: saml2.extension.mdui
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mduma` Module
-------------------

.. automodule:: saml2.extension.mduma
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pefim` Module
-------------------

.. automodule:: saml2.extension.pefim
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`shibmd` Module
--------------------

.. automodule:: saml2.extension.shibmd
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`ui` Module
----------------

.. automodule:: saml2.extension.ui
    :members:
    :undoc-members:
    :show-inheritance:

