attributemaps Package
=====================

:mod:`attributemaps` Package
----------------------------

.. automodule:: saml2.attributemaps
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`adfs_v1x` Module
----------------------

.. automodule:: saml2.attributemaps.adfs_v1x
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`adfs_v20` Module
----------------------

.. automodule:: saml2.attributemaps.adfs_v20
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`basic` Module
-------------------

.. automodule:: saml2.attributemaps.basic
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`saml_uri` Module
----------------------

.. automodule:: saml2.attributemaps.saml_uri
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`shibboleth_uri` Module
----------------------------

.. automodule:: saml2.attributemaps.shibboleth_uri
    :members:
    :undoc-members:
    :show-inheritance:

